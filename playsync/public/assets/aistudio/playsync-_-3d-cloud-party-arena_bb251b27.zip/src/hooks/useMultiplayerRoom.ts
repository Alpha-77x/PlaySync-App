import { useCallback, useEffect, useRef, useState } from 'react';
import type { ArenaModeId, InputType } from '../engine/arenaLogic';
import type {
  ClientToServerMessage,
  PlayerNetTransform,
  ServerRoomSnapshot,
  ServerToClientMessage,
} from '../shared/multiplayerProtocol';

export interface RemoteActionEvent {
  clientId: string;
  actionType: 'fire' | 'surge' | 'wave' | 'pulse';
  x: number;
  z: number;
  heading: number;
}

export interface RoomFeedEvent {
  id: string;
  text: string;
  accent?: string;
}

interface PendingJoinPayload {
  roomPin?: string;
  modeId: ArenaModeId;
  playerName: string;
  inputType: InputType;
  liveryColor: string;
}

export function useMultiplayerRoom() {
  const [wsConnected, setWsConnected] = useState(false);
  const [clientId, setClientId] = useState<string | null>(null);
  const [pingMs, setPingMs] = useState<number>(8);
  const [roomSnapshot, setRoomSnapshot] = useState<ServerRoomSnapshot | null>(null);
  const [roomError, setRoomError] = useState<string | null>(null);
  const [roomEvents, setRoomEvents] = useState<RoomFeedEvent[]>([]);

  const wsRef = useRef<WebSocket | null>(null);
  const clientIdRef = useRef<string | null>(null);
  const pendingJoinRef = useRef<PendingJoinPayload | null>(null);
  const remoteVehiclesRef = useRef<Map<string, PlayerNetTransform>>(new Map());
  const remoteActionsRef = useRef<RemoteActionEvent[]>([]);
  const reconnectTimerRef = useRef<number | null>(null);
  const lastStateSentRef = useRef<number>(0);

  const sendRaw = useCallback((msg: ClientToServerMessage) => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(msg));
      return true;
    }
    return false;
  }, []);

  useEffect(() => {
    let disposed = false;
    let attempt = 0;

    function connect() {
      if (disposed) return;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const url = `${protocol}//${window.location.host}/ws`;
      let ws: WebSocket;
      try {
        ws = new WebSocket(url);
      } catch {
        const delay = Math.min(8000, 1000 * Math.pow(1.5, attempt++));
        reconnectTimerRef.current = window.setTimeout(connect, delay);
        return;
      }
      wsRef.current = ws;

      ws.addEventListener('open', () => {
        if (disposed) return;
        attempt = 0;
        setWsConnected(true);
        setRoomError(null);
        ws.send(JSON.stringify({ type: 'ping:req', t: Date.now() }));

        if (pendingJoinRef.current) {
          const j = pendingJoinRef.current;
          ws.send(
            JSON.stringify({
              type: 'room:join',
              roomPin: j.roomPin,
              modeId: j.modeId,
              playerName: j.playerName,
              inputType: j.inputType,
              liveryColor: j.liveryColor,
            })
          );
        }
      });

      ws.addEventListener('message', (event) => {
        if (disposed) return;
        let msg: ServerToClientMessage;
        try {
          msg = JSON.parse(String(event.data)) as ServerToClientMessage;
        } catch {
          return;
        }

        if (msg.type === 'welcome') {
          clientIdRef.current = msg.clientId;
          setClientId(msg.clientId);
          return;
        }

        if (msg.type === 'pong') {
          const rtt = Math.max(1, Math.round(Date.now() - msg.t));
          setPingMs(rtt);
          return;
        }

        if (msg.type === 'room:error') {
          setRoomError(msg.message);
          return;
        }

        if (msg.type === 'room:state') {
          setRoomSnapshot(msg.room);
          setRoomError(null);

          // Sync remote vehicle map (exclude local client)
          const nextMap = new Map<string, PlayerNetTransform>();
          for (const p of msg.room.players) {
            if (p.clientId !== clientIdRef.current) {
              const existing = remoteVehiclesRef.current.get(p.clientId);
              nextMap.set(
                p.clientId,
                existing
                  ? {
                      ...p,
                      x: existing.x,
                      z: existing.z,
                      heading: existing.heading,
                      turretAngle: existing.turretAngle,
                    }
                  : p
              );
            }
          }
          remoteVehiclesRef.current = nextMap;
          return;
        }

        if (msg.type === 'player:state') {
          if (msg.clientId === clientIdRef.current) return;
          const prev = remoteVehiclesRef.current.get(msg.clientId);
          if (prev) {
            prev.x = msg.x;
            prev.z = msg.z;
            prev.heading = msg.heading;
            prev.speed = msg.speed;
            prev.score = msg.score;
            prev.hits = msg.hits;
            prev.isBoosting = msg.isBoosting;
            prev.shieldActive = msg.shieldActive;
            prev.turretAngle = msg.turretAngle;
            prev.updatedAt = Date.now();
          }
          return;
        }

        if (msg.type === 'player:action') {
          if (msg.clientId === clientIdRef.current) return;
          remoteActionsRef.current.push({
            clientId: msg.clientId,
            actionType: msg.actionType,
            x: msg.x,
            z: msg.z,
            heading: msg.heading,
          });
          return;
        }

        if (msg.type === 'room:event') {
          setRoomEvents((prev) => [
            { id: `${Date.now()}-${Math.random()}`, text: msg.text, accent: msg.accent },
            ...prev.slice(0, 4),
          ]);
        }
      });

      ws.addEventListener('close', () => {
        if (disposed) return;
        setWsConnected(false);
        const delay = Math.min(4000, 800 * Math.pow(1.6, attempt++));
        reconnectTimerRef.current = window.setTimeout(connect, delay);
      });

      ws.addEventListener('error', () => {
        ws.close();
      });
    }

    connect();

    const pingInterval = window.setInterval(() => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'ping:req', t: Date.now() }));
      }
    }, 5000);

    return () => {
      disposed = true;
      window.clearInterval(pingInterval);
      if (reconnectTimerRef.current !== null) {
        window.clearTimeout(reconnectTimerRef.current);
      }
      wsRef.current?.close();
    };
  }, []);

  const joinRoom = useCallback(
    (payload: PendingJoinPayload) => {
      pendingJoinRef.current = payload;
      setRoomError(null);
      sendRaw({
        type: 'room:join',
        roomPin: payload.roomPin,
        modeId: payload.modeId,
        playerName: payload.playerName,
        inputType: payload.inputType,
        liveryColor: payload.liveryColor,
      });
    },
    [sendRaw]
  );

  const leaveRoom = useCallback(() => {
    pendingJoinRef.current = null;
    remoteVehiclesRef.current.clear();
    setRoomSnapshot(null);
    sendRaw({ type: 'room:leave' });
  }, [sendRaw]);

  const setReady = useCallback(
    (ready: boolean) => {
      sendRaw({ type: 'room:ready', ready });
    },
    [sendRaw]
  );

  const setLivery = useCallback(
    (liveryColor: string) => {
      if (pendingJoinRef.current) {
        pendingJoinRef.current = { ...pendingJoinRef.current, liveryColor };
      }
      sendRaw({ type: 'room:livery', liveryColor });
    },
    [sendRaw]
  );

  const setRoundSeconds = useCallback(
    (roundSeconds: number) => {
      sendRaw({ type: 'room:settings', roundSeconds });
    },
    [sendRaw]
  );

  const addBot = useCallback(
    (name?: string) => {
      sendRaw({ type: 'room:add_bot', name });
    },
    [sendRaw]
  );

  const removeSlot = useCallback(
    (slotNumber: number) => {
      sendRaw({ type: 'room:remove_slot', slotNumber });
    },
    [sendRaw]
  );

  const regeneratePin = useCallback(() => {
    sendRaw({ type: 'room:regenerate_pin' });
  }, [sendRaw]);

  const startMatch = useCallback(
    (sandbox: boolean) => {
      sendRaw({ type: 'match:start', sandbox });
    },
    [sendRaw]
  );

  const pauseMatch = useCallback(
    (paused: boolean) => {
      sendRaw({ type: 'match:pause', paused });
    },
    [sendRaw]
  );

  const endMatch = useCallback(() => {
    sendRaw({ type: 'match:end' });
  }, [sendRaw]);

  // Throttled ~18Hz state emitter for smooth multiplayer sync
  const sendVehicleState = useCallback(
    (state: {
      x: number;
      z: number;
      heading: number;
      speed: number;
      score: number;
      hits: number;
      isBoosting: boolean;
      shieldActive: boolean;
      turretAngle: number;
    }) => {
      const now = performance.now();
      if (now - lastStateSentRef.current < 55) return;
      lastStateSentRef.current = now;
      sendRaw({ type: 'player:state', ...state });
    },
    [sendRaw]
  );

  const sendActionEvent = useCallback(
    (actionType: 'fire' | 'surge' | 'wave' | 'pulse', x: number, z: number, heading: number) => {
      sendRaw({ type: 'player:action', actionType, x, z, heading });
    },
    [sendRaw]
  );

  const sendHitEvent = useCallback(
    (points: number, reason: string, targetClientId?: string) => {
      sendRaw({ type: 'player:hit', points, reason, targetClientId });
    },
    [sendRaw]
  );

  return {
    wsConnected,
    clientId,
    pingMs,
    roomSnapshot,
    roomError,
    roomEvents,
    remoteVehiclesRef,
    remoteActionsRef,
    joinRoom,
    leaveRoom,
    setReady,
    setLivery,
    setRoundSeconds,
    addBot,
    removeSlot,
    regeneratePin,
    startMatch,
    pauseMatch,
    endMatch,
    sendVehicleState,
    sendActionEvent,
    sendHitEvent,
  };
}
